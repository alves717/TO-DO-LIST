# To-Do (Django) - Projeto baseado na foto enviada

Tema: Lista de Tarefas (To-Do)
Requisitos da foto:
- Aplicação web escrita em Django
- Banco: SQLite (padrão do Django)
- Mínimo 4 histórias de usuário

Imagem (referência enviada pelo usuário): /mnt/data/E638C0AB-8628-47CA-BC17-18226D9150E4.jpeg

## Como usar (desenvolvimento)
1. Crie ambiente virtual e ative-o.
2. Instale dependências: `pip install -r requirements.txt`
3. Rode migrações:
   ```
   python manage.py migrate
   python manage.py createsuperuser
   python manage.py runserver
   ```
4. Acesse `http://127.0.0.1:8000/`

## O que está incluído
- Projeto Django mínimo com app `todo`
- Models: Task (tarefa)
- Views, forms, templates para CRUD de tarefas e autenticação básica (signup/login)
- SQLite via Django (db.sqlite3 gerado ao rodar migrate)

