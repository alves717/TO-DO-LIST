# Histórias de usuário (mínimo 4)

1. Como usuário, quero me cadastrar e fazer login para poder criar e gerenciar minhas tarefas.
   - Critérios de aceitação:
     - Sistema permite cadastro com username e senha.
     - Após cadastro o usuário é autenticado automaticamente.

2. Como usuário autenticado, quero criar tarefas com título, descrição e prazo para organizar minhas atividades.
   - Critérios de aceitação:
     - Formulário de criação existe e salva a tarefa vinculada ao usuário.

3. Como usuário, quero marcar tarefas como concluídas para controlar o que já foi feito.
   - Critérios de aceitação:
     - Campo 'completed' está disponível para edição.

4. Como usuário, quero editar e excluir minhas tarefas para manter a lista atualizada.
   - Critérios de aceitação:
     - Páginas de edição e confirmação de exclusão funcionam apenas para o autor.

