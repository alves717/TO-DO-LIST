from django.shortcuts import render, redirect, get_object_or_404
from .models import Task
from .forms import TaskForm, SignUpForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.core.paginator import Paginator

def index(request):
    if request.user.is_authenticated:
        tasks = Task.objects.filter(author=request.user).order_by('-created_at')
    else:
        tasks = Task.objects.none()
    # simple pagination
    paginator = Paginator(tasks, 10)
    page = request.GET.get('page')
    tasks_page = paginator.get_page(page)
    return render(request, 'todo/index.html', {'tasks': tasks_page})

@login_required
def task_create(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            t = form.save(commit=False)
            t.author = request.user
            t.save()
            return redirect('todo:index')
    else:
        form = TaskForm()
    return render(request, 'todo/task_form.html', {'form': form, 'title': 'Criar Tarefa'})

@login_required
def task_detail(request, pk):
    task = get_object_or_404(Task, pk=pk, author=request.user)
    return render(request, 'todo/task_detail.html', {'task': task})

@login_required
def task_edit(request, pk):
    task = get_object_or_404(Task, pk=pk, author=request.user)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('todo:task_detail', pk=task.pk)
    else:
        form = TaskForm(instance=task)
    return render(request, 'todo/task_form.html', {'form': form, 'title': 'Editar Tarefa'})

@login_required
def task_delete(request, pk):
    task = get_object_or_404(Task, pk=pk, author=request.user)
    if request.method == 'POST':
        task.delete()
        return redirect('todo:index')
    return render(request, 'todo/task_confirm_delete.html', {'task': task})

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('todo:index')
    else:
        form = SignUpForm()
    return render(request, 'todo/signup.html', {'form': form})
