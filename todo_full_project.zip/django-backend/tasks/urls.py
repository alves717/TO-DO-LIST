from django.urls import path
from . import views
app_name = 'tasks'
urlpatterns = [
    path('', views.index, name='index'),
    path('create/', views.task_create, name='create'),
    path('edit/<int:pk>/', views.task_edit, name='edit'),
    path('delete/<int:pk>/', views.task_delete, name='delete'),
    path('toggle/<int:pk>/', views.toggle_complete, name='toggle'),
    path('register/', views.register, name='register'),
]
