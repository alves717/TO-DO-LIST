ToDo Full Project (Django + DRF backend + React frontend)
=========================================================

What's included
- django-backend/: Django project (todo_project) + app tasks
  * Uses SQLite (db.sqlite3) by default
  * Includes Django REST Framework endpoints (API)
  * Includes standard templates for server-rendered pages (with Tailwind-ready setup)
- react-frontend/: React app (create-react-app-like structure) that talks to the API
- requirements.txt: Python dependencies (Django, djangorestframework)
- README with quick-start instructions

Quick start (Backend)
1. Create virtualenv and activate it:
   python -m venv venv
   source venv/bin/activate     (Linux/macOS) or venv\Scripts\activate (Windows)
2. Install dependencies:
   pip install -r requirements.txt
3. From django-backend directory run:
   python manage.py migrate
   python manage.py createsuperuser  # optional
   python manage.py runserver
4. The API endpoints are available at http://127.0.0.1:8000/api/tasks/

Quick start (Frontend)
1. cd react-frontend
2. npm install
3. npm start
4. Edit `src/config.js` to point to your backend API base URL (default http://127.0.0.1:8000)

Notes
- The React app is a minimal skeleton using fetch to call the DRF API.
- Tailwind is prepared via CDN usage in templates; for full Tailwind integration you may add PostCSS setup.
