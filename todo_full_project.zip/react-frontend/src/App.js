import React, {useState, useEffect} from 'react';
import { API_BASE } from './config';

function App(){
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  useEffect(()=> fetchTasks(), []);
  function fetchTasks(){
    fetch(API_BASE + '/tasks/', {credentials:'include'})
      .then(r=>r.json()).then(data=>setTasks(data));
  }
  function createTask(e){
    e.preventDefault();
    fetch(API_BASE + '/tasks/', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      credentials:'include',
      body:JSON.stringify({title, description:desc})
    }).then(()=>{ setTitle(''); setDesc(''); fetchTasks(); });
  }
  function toggle(id, completed){
    fetch(API_BASE + '/tasks/' + id + '/', {
      method:'PATCH',
      headers:{'Content-Type':'application/json'},
      credentials:'include',
      body:JSON.stringify({completed: !completed})
    }).then(()=>fetchTasks());
  }
  function remove(id){
    fetch(API_BASE + '/tasks/' + id + '/', {
      method:'DELETE', credentials:'include'
    }).then(()=>fetchTasks());
  }
  return (
    <div style={{maxWidth:800, margin:'24px auto', fontFamily:'Arial'}}>
      <h1>ToDo — React Frontend</h1>
      <form onSubmit={createTask}>
        <input required placeholder='Título' value={title} onChange={e=>setTitle(e.target.value)} />
        <br/>
        <textarea placeholder='Descrição' value={desc} onChange={e=>setDesc(e.target.value)} />
        <br/>
        <button type='submit'>Criar</button>
      </form>
      <hr/>
      <ul>
        {tasks.map(t=>(
          <li key={t.id}>
            <strong style={{textDecoration:t.completed?'line-through':'none'}}>{t.title}</strong>
            <div>{t.description}</div>
            <button onClick={()=>toggle(t.id, t.completed)}>{t.completed?'Marcar pendente':'Marcar concluída'}</button>
            <button onClick={()=>remove(t.id)}>Excluir</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
